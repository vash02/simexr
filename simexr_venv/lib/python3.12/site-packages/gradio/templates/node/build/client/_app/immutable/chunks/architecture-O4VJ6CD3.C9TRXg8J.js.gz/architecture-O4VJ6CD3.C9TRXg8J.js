import{A as c,e as t}from"./mermaid-parser.core.BIJ9Hkl4.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-O4VJ6CD3.C9TRXg8J.js.map
