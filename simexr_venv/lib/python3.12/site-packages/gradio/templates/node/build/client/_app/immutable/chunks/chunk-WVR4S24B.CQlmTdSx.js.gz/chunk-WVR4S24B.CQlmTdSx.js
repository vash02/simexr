import{_ as s}from"./mermaid.core.2pwqAD7o.js";import{s as o}from"./select.BigU4G0v.js";var d=s((t,e)=>{let n;return e==="sandbox"&&(n=o("#i"+t)),(e==="sandbox"?o(n.nodes()[0].contentDocument.body):o("body")).select(`[id="${t}"]`)},"getDiagramElement");export{d as g};
//# sourceMappingURL=chunk-WVR4S24B.CQlmTdSx.js.map
