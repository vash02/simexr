import{v as o}from"./2.DPLbyeoY.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.B2wpAx2G.js.map
