import{G as a,f as G}from"./mermaid-parser.core.BIJ9Hkl4.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-ZV4HHKMB.BfgTGDmg.js.map
