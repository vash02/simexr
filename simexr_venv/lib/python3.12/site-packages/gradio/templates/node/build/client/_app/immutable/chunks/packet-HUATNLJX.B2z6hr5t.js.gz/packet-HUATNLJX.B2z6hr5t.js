import{P as c,a as r}from"./mermaid-parser.core.BIJ9Hkl4.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.B2z6hr5t.js.map
