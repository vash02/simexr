import{s as a,S as t,b as r,a as s}from"./chunk-LXBSTHXV.Ba2J1PAP.js";import{_ as i}from"./mermaid.core.2pwqAD7o.js";var _={parser:a,get db(){return new t(2)},renderer:r,styles:s,init:i(e=>{e.state||(e.state={}),e.state.arrowMarkerAbsolute=e.arrowMarkerAbsolute},"init")};export{_ as diagram};
//# sourceMappingURL=stateDiagram-v2-EYPG3UTE.hHUK9amz.js.map
