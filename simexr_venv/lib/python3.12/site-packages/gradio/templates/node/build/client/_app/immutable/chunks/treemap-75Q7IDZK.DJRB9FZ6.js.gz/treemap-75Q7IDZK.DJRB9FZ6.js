import{T as a,h as m}from"./mermaid-parser.core.BIJ9Hkl4.js";export{a as TreemapModule,m as createTreemapServices};
//# sourceMappingURL=treemap-75Q7IDZK.DJRB9FZ6.js.map
