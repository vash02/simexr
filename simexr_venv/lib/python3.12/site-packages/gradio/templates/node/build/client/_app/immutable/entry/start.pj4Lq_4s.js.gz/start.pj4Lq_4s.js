import{s as t}from"../chunks/client.--7n92yq.js";export{t as start};
//# sourceMappingURL=start.pj4Lq_4s.js.map
